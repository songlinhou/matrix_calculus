from matrix_calculus import Ma

def 